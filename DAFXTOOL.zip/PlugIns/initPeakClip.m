function stAlgo = initPeakClip(stAlgo)

% ******************************************************
% * Peak Clipper
% * ----------------------------------------------------
% * Author  :   Joeorg Bitzer
% * Date    :   Dec 2004
% * Version 1
% *
% * Fachhochschule OOW Standort Oldenburg
% * Studiengang H�rtechnik und Audiologie
% ******************************************************
 
global ParaEingabe;

disp('******* Peak Clipper *******');
if (ParaEingabe == 0)
    stAlgo.InputGain_db = 6; %default
    szOut = sprintf('Using default values, Gain = %1.2f dB',stAlgo.InputGain_db);
    disp(szOut);
else    
   disp('Enter input gain [dB]:');
   stAlgo.InputGain_db = input('');
     
 end




