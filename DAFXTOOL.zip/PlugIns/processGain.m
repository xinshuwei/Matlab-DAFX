

function [stAlgo, status, data] = processGain(data, stAlgo)

status = 0;

data = data.*stAlgo.gain_lin;



