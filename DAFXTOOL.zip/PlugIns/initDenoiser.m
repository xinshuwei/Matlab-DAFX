function stAlgo = initDenoiser(stAlgo)

% ******************************************************
% * 
% * ----------------------------------------------------
% * Author  :   
% * Date    :   
% * Last modified:
% *
% * Fachhochschule OOW Standort Oldenburg
% * Studiengang H�rtechnik und Audiologie
% ******************************************************
 
global ParaEingabe;

disp('******* Denoiser *******');
if (ParaEingabe == 0)
    stAlgo.Denoisecoeff = 0.007; %default
    szOut = sprintf('Using default values, Denoisefactor = %1.5f ',stAlgo.Denoisecoeff);
    disp(szOut);
else    
   disp('Enter denoise-factor(e.g. 0.01):');
   stAlgo.Denoisecoeff = input('');
      
 end
