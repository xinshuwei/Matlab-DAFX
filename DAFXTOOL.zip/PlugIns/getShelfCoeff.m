function [b,a] = getShelfCoeff(fs,fc,Gain_dB,typ,mode)
% *** getShelfCoeff ************************************
% * 
% * Generates a high or low Shelving-Filter with the
% * algorithm of Udo Z�lzer and Bobert Bristow Johnson.
% * 
% * Usage:
% * -------
% * [b,a]=getShelfCoeff(fs,fc,Gain,type,mode);
% *
% *   fs = Sampling frequency in Hz
% *   fc = Cutoff frequency in Hz
% * Gain = Gain in dB
% * type = 'high' for High-Shelving
% *        'low'  for Low-Shelving
% * mode = 'RBJ'  for the algorithm of
% *               Bobert Bristow Johnson
% *        'Zoel' for the algorithm of
% *               Udo Z�lzer
% * 
% *************************************************************************
% * (c) IHA @ Fachhochule Oldenburg / Ostfriesland / Wilhelmshaven 
% * for the applied licence see EOF
% * written by Timm Schaer, Alexandra Mueller, Daniel Visser, Gabor Peli,
%   Ansgar Wempe
% * History
% *                 Version 0.9   Nov 2004                     FH OOW
% *
% * Fachhochschule OOW Standort Oldenburg
% * Studiengang H�rtechnik und Audiologie
% *
% * Version 2.2 - 01.11.2004 - 10:24 
% * Version 2.3 - 18.11.2004  aufgeraeumt, structs entfernt
% ******************************************************

if nargin < 5
    mode = 'RBJ'; % Default filter structure
end
if nargin < 4
    typ = 'low'; % Default filter type
end
if nargin < 3
    Gain_dB = 10; % Default gain
end
if nargin < 2
    fc = 1000; % Default cutoff frequency
end
if nargin < 1
    fs = 44100; % Default sampling frequency
end

if(fc>(fs/2))
    error('Cutoff frequency exceeds Nyquistfrequency!');
end

switch mode
    case 1 %Zoelzer
        K = tan(pi*fc/fs); % Frequency
        switch typ
            case 1
                if Gain_dB>0
                    V0 = 10^(Gain_dB/20); % Gain
                    % Generates the filter coefficients for a low shelving filter
                    b0 = (1 + sqrt(2 * V0) * K + V0 * K * K)/(1 + sqrt(2) * K + K * K);
                    b1 = (2 * (V0 * K * K - 1))/(1 + sqrt(2) * K + K * K);
                    b2 = (1-sqrt(2 * V0) * K + V0 * K * K)/(1 + sqrt(2) * K + K * K);
                    a0 = 1;
                    a1 = (2 * (K * K -1))/(1 + sqrt(2) * K + K * K);
                    a2 = (1 - sqrt(2) * K + K * K)/(1 + sqrt(2) * K + K * K);
                else
                    V0 = 10^(-Gain_dB/20); % Gain
                    b0 = (1 + sqrt(2) * K + K^2)/(1 + sqrt(2 * V0) * K + V0 * K^2);
                    b1 = (2 * (K^2 - 1))/(1 + sqrt(2 * V0) * K + V0 * K^2);
                    b2 = (1 - sqrt(2) * K + K^2)/(1 + sqrt(2 * V0) * K + V0 * K^2);
                    a0 = 1;
                    a1 = (2 * (V0 * K^2 - 1))/(1 + sqrt(2 * V0) * K + V0 * K^2);
                    a2 = (1 - sqrt(2 * V0) * K + V0 * K^2)/(1 + sqrt(2 * V0) * K+V0 * K^2);
                end
            case 2
                if Gain_dB>0
                    % Generates the filter coefficients for a high shelving filter
                    V0 = 10^(Gain_dB/20); % Gain
                    b0 = (V0 + sqrt(2 * V0) * K + K * K)/(1 + sqrt(2) * K + K * K);
                    b1 = (2 * (K * K - V0))/(1 + sqrt(2) * K + K * K);
                    b2 = (V0 - sqrt(2 * V0) * K + K * K)/(1 + sqrt(2) * K + K * K);
                    a0 = 1;
                    a1 = (2 * (K * K - 1))/(1 + sqrt(2) * K + K * K);
                    a2 = (1 - sqrt(2) * K + K * K)/(1 + sqrt(2) * K + K * K);
                else
                    V0 = 10^(-Gain_dB/20); % Gain
                    b0 = (1 + sqrt(2) * K + K ^ 2 ) / (V0 + sqrt(2 * V0) * K + K ^ 2);
                    b1 = (2 * (K^2 - 1)) / (V0 + sqrt(2 * V0) * K + K ^ 2);
                    b2 = (1 - sqrt(2) * K + K^2 ) / (V0 + sqrt(2 * V0) * K + K ^ 2);
                    a0 = 1;
                    %a1 = (2 * (K^2 / (V0 - 1) ) ) / (1 + sqrt(2 / V0) * K + (K^2)/V0);
                     a1 = (2 * (K^2 / V0 - 1 ) ) / (1 + sqrt(2 / V0) * K + ( K^2 )/V0);
                    a2 = (1 - sqrt(2/V0)*K + K^2/V0 )/(1 + sqrt(2 / V0) * K + (K^2)/V0);
                end
            otherwise
                error('Wrong filter type');
        end
        a = [a0 a1 a2];
        b = [b0 b1 b2];
    case 2
        a = 10^(Gain_dB/40); % Gain
        om = 2 * pi * fc / fs; % Frequency
        Q = 1/sqrt(2);
        beta = sqrt(a)/Q;
        switch typ 
            case 1
                b0 = a * ((a + 1) + (a - 1) * cos(om)    + beta * sin(om));
                b1 = -2 *a * ((a - 1) + (a + 1) * cos(om));
                b2 = a * ((a + 1) + (a - 1) * cos(om)    - beta * sin(om));
                a0 = (a + 1) - (a - 1) * cos(om)    + beta * sin(om);
                a1 = 2 * ((a - 1) - (a + 1) * cos(om));
                a2 = (a + 1) - (a - 1) * cos(om)     - beta * sin(om);
            case 2
                b0 = a * ((a+1) - (a-1) * cos(om) + beta * sin(om));
                b1 = 2*a * ((a-1) - (a+1) * cos(om));
                b2 = a* ((a+1) - (a-1) * cos(om) - beta*sin(om));
                a0 = (a+1) + (a-1) * cos(om) + beta * sin(om);
                a1 = -2* ((a-1) + (a+1) * cos(om));
                a2 = (a+1) + (a-1) *cos(om) - beta*sin(om);
            otherwise
                error('Wrong input');
        end      
        b = [b0 b1 b2]./a0;
        a = [a0 a1 a2]./a0;
    otherwise
        error('Wrong filter type');
end

%--------------------Licence ---------------------------------------------
% Copyright (c) <2004> Timm Schaer, Alexandra Mueller, Joerg Bitzer, 
% Daniel Visser, Ansgar Wempe, Gabor Peli
% Institute for Hearing Technology and Audiology
% University of Applied Sciences Oldenburg / Ostfriesland / Wilhelmshaven
% Permission is hereby granted, free of charge, to any person obtaining 
% a copy of this software and associated documentation files 
% (the "Software"), to deal in the Software without restriction, including 
% without limitation the rights to use, copy, modify, merge, publish, 
% distribute, sublicense, and/or sell copies of the Software, and to 
% permit persons to whom the Software is furnished to do so, subject 
% to the following conditions:
% The above copyright notice and this permission notice shall be included 
% in all copies or substantial portions of the Software.

% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
% EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES 
% OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
% IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
% CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
% TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
% SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
