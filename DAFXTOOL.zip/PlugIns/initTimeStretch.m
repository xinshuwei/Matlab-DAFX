function stAlgo = initTimeStretch(stAlgo)

% ******************************************************
% * 
% * ----------------------------------------------------
% * Author  :   Dominik Wegmann
% * Date    :   Nov 2006
% * Version 1
% *
% * 
% ******************************************************
 
global ParaEingabe;

disp('******* Time Stretching *******');
if (ParaEingabe == 0)
    stAlgo.stretchfactor = 0.7; %default
    stAlgo.pitchcorrection = 1;
    szOut = sprintf('Using default values, Stretchfactor = %1.2f ',stAlgo.stretchfactor);
    disp(szOut);
else    
   disp('Enter stretching/ramming factor (e.g. 0.8) :');
   stAlgo.stretchfactor = input('');
      while(stAlgo.stretchfactor < 0.1 || stAlgo.stretchfactor > 5)
           disp('Sorry, limited from 0.1 to 5!');
           disp('Enter stretching/ramming factor:');
           stAlgo.stretchfactor = input('');
      end
       disp('Keep source pitch? (0 = no, 1 = yes):');
       stAlgo.pitchcorrection = input('');
end
 