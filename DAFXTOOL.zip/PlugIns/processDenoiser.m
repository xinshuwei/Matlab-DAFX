function [stAlgo, status, data] = processDenoiser(data, stAlgo)

status = 0;

% Code from VX_denoise.m by Zoelzer
%===== this program makes a denoising of a sound, using:
%===== w1 and w2 windows (analysis and synthesis)
%===== WLen is the length of the windows
%===== n1 and n2: steps (in samples) for the analysis and synthesis

%----- user data -----
n1            = 512;
n2            = n1;
WLen          = 1024;
w1            = hanning(WLen);
w2            = w1;
DAFx_in = data;
%----- initializations -----
L = length(DAFx_in);
DAFx_in = [zeros(WLen, 1); DAFx_in; ...
   zeros(WLen-mod(L,n1),1)] / max(abs(DAFx_in));
WLen2         = WLen/2;
coef          = stAlgo.Denoisecoeff;
DAFx_out      = zeros(length(DAFx_in),1);

tic
%UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU
pin  = 0;
pout = 0;
pend = length(DAFx_in) - WLen;

while pin<pend
    grain = DAFx_in(pin+1:pin+WLen).* w1;
%===========================================
    f     = fft(grain);
    r     = abs(f)/WLen2;
    ft    = f.*r./(r+coef);
    grain = (real(ifft(ft))).*w2;
% ===========================================
    DAFx_out(pout+1:pout+WLen) = ...
        DAFx_out(pout+1:pout+WLen) + grain;
    pin  = pin + n1;
    pout = pout + n2;
end
%UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU

DAFx_out = DAFx_out(WLen+1:WLen+L);
data = DAFx_out;