function stAlgo = initDistort(stAlgo)

% ******************************************************
% * Distortion 
% * ----------------------------------------------------
% * Author  :   Dominik Wegmann
% * Date    :   10/2005
% * Last modified: 2.11.05
% *
% * Fh Oldenburg
% * Institut f. H�rtechnik und Audiologie
% ******************************************************
 
global ParaEingabe;

disp('******* Distortion *******')
if (ParaEingabe == 0)
    stAlgo.dist = 0.75;
    szOut = sprintf('Using default values, distortion amount = %1.2f',stAlgo.dist);
    disp(szOut)
else    
   disp('Enter amount of distortion (0...1):');
   stAlgo.dist = input('');
      while(stAlgo.dist < 0 || stAlgo.dist > 1)
           disp('Amount is limited to 0...1!');
           disp('Amount of distortion (0...1):');
           stAlgo.dist = input('');
       end
 end
