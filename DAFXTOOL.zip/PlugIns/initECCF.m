function stAlgo = initECCF(stAlgo)
% ******************************************************
% * Envelope Controlled EQ using Chamberlin Topology
% * ----------------------------------------------------
% * Author  :   Niklas Harlander, Dominik Wegmann
% * Date    :   Dec 2004
% * Version 2
% * Last modified: 04.11.2006 (D.W.)
% * Fachhochschule OOW Standort Oldenburg
% * Studiengang H�rtechnik und Audiologie
% ******************************************************
global ParaEingabe;

disp('******* Envelope Controlled Equalizer *******');

if (ParaEingabe == 1)  %globale Abfrage nach Eingabem�glichkeit einzelner Parameter

    disp('****** Filter Values ******');
    stAlgo.fc_max = input('Enter maximum cut-off frequency [Hz]: ');
    while(stAlgo.fc_max < 100 || stAlgo.fc_max > 20000)
        disp('Frequency is limited from 100 to 20000 Hz!');
        disp('Enter maximum cut-off frequency [Hz]:');
        stAlgo.fc_max = input('');
    end
    %Eingabe der Filterparameter fc un Q
    stAlgo.Q = input('Enter Q-factor : ');
    while(stAlgo.Q < 0.1 || stAlgo.Q > 7)
        disp('Q is limited from 0.1 to 7!');
        disp('Enter Q-factor:');
        stAlgo.Q = input('');
    end
    stAlgo.sens = input('Enter envelope sensitivity (0...1): ');
    while(stAlgo.sens < 0.01 || stAlgo.sens > 1)
        disp('Sensitivity is limited from 0.01 to 1 ');               %Empfindlichkeit Envelope
        disp('Enter envelope sensitivity (0...1):');
        stAlgo.sens = input('');
        %
    end

   
else
    stAlgo.fc_max = 12000;
    stAlgo.Q = 3;            %Default-Werte
    stAlgo.sens = 0.07;
    %stAlgo.gain_db = -6;

    sprintf('Using default values: Q = %1.1f , fc = %.1f Hz, Sensitivity = %1.1f', stAlgo.Q, stAlgo.fc_max, stAlgo.sens)

end


stAlgo.sens = stAlgo.sens*0.01;   %Berechnung der Envelope-Empfindlichkeit
stAlgo.states = zeros(1,3); %erste Samples f�r Berechnung des Filters 1. x(n-1) 2.y(n-1) 3.y(n-2)
stAlgo.statesFIR = zeros(1,2);


%--------------------Licence ---------------------------------------------
% Copyright (c) <2004> Niklas Harlander, Dominik Wegmann
% Institute for Hearing Technology and Audiology
% University of Applied Sciences Oldenburg / Ostfriesland / Wilhelmshaven
% Permission is hereby granted, free of charge, to any person obtaining
% a copy of this software and associated documentation files
% (the "Software"), to deal in the Software without restriction, including
% without limitation the rights to use, copy, modify, merge, publish,
% distribute, sublicense, and/or sell copies of the Software, and to
% permit persons to whom the Software is furnished to do so, subject
% to the following conditions:
% The above copyright notice and this permission notice shall be included
% in all copies or substantial portions of the Software.

% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
% EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
% OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
% IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
% CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
% TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
% SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
