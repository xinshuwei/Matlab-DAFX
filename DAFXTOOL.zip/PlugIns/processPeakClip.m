function [stAlgo, status, data] = processPeakClip(data, stAlgo)

status = 0;


Gain = 10^(stAlgo.InputGain_db/20);

% % Direct Clipping
% 
% ClipSignal = data.*Gain;
% idx = find(ClipSignal >=1);
% ClipSignal(idx) = 1;
% idx = find(ClipSignal <-1);
% ClipSignal(idx) = -1;


% Soft-Clipping

NewGain = Gain/1.7;

SoftClipSignal = NewGain.*data;

idx = find(SoftClipSignal >=1);
SoftClipSignal(idx) = 1;
idx = find(SoftClipSignal <-1);
SoftClipSignal(idx) = -1;

idx = find (SoftClipSignal < 1 & SoftClipSignal >=-1);
SoftClipSignal(idx) = 1.5*SoftClipSignal(idx)-1/2.*SoftClipSignal(idx).*SoftClipSignal(idx).*SoftClipSignal(idx);
data = SoftClipSignal;









