function stAlgo = initAlgo(ID,fs)
%function initAlgo
% ******************************************************
% * Author  :   Dominik Wegmann <audioholiker@web.de>
% * Date    :   10/2005
% * Last modified: 31.10.2006
% ******************************************************
%initAlgo is a part of "dafxtool.m" and is launched by the function "fxprocessing.m"
%Add your PlugIns here by assigning ID and PlugIn-name.
%Your PlugIn must provide at least two files: 1)initYOURPLUGIN
%                                             2)processYOURPLUGIN
%
%Add the IDs and names to matrices "FXNAME" and "FXID" in dafxtool.m


stAlgo.fs = fs;

switch ID
    case 1
        stAlgo.ID = 1;
        stAlgo.name = 'Gain';
        stAlgo.ProcessName = '[MetaStr.(name_str), status, data] = processGain(data, MetaStr.(name_str));';
        stAlgo = initGain(stAlgo);


    case 10 %Filter/EQ
        stAlgo.ID = 10;
        stAlgo.name = 'Peak EQ';
        stAlgo.ProcessName = '[MetaStr.(name_str), status, data] = processPeakEQ(data, MetaStr.(name_str));';
        stAlgo = initPeakEQ(stAlgo);
    case 11
        stAlgo.ID = 11;
        stAlgo.name = 'Shelf EQ';
        stAlgo.ProcessName = '[MetaStr.(name_str), status, data] = processShelfEQ(data, MetaStr.(name_str));';
        stAlgo = initShelfEQ(stAlgo);

    case 12
        stAlgo.ID = 12;
        stAlgo.name = 'ECCF';
        stAlgo.ProcessName = '[MetaStr.(name_str), status, data] = processECCF(data, MetaStr.(name_str));';
        stAlgo = initECCF(stAlgo);

    case 30 %Dynamics
        stAlgo.ID = 30;
        stAlgo.name = 'Peak-Clipper';
        stAlgo.ProcessName = '[MetaStr.(name_str), status, data] = processPeakClip(data, MetaStr.(name_str));';
        stAlgo = initPeakClip(stAlgo);

    case 31
        stAlgo.ID = 31;
        stAlgo.name = 'Look-Ahead Limiter';
        stAlgo.ProcessName = '[MetaStr.(name_str), status, data] = processLookAheadLimiter(data, MetaStr.(name_str));';
        stAlgo = initLookAheadLimiter(stAlgo);

    case 32
        stAlgo.ID = 32;
        stAlgo.name = 'Noise Gate';
        stAlgo.ProcessName = '[MetaStr.(name_str), status, data] = processGate(data, MetaStr.(name_str));';
        stAlgo = initGate(stAlgo);

    case 40 %Distortions
        stAlgo.ID = 40;
        stAlgo.name = 'Distort';
        stAlgo.ProcessName = '[MetaStr.(name_str), status, data] = processDistort(data, MetaStr.(name_str));';
        stAlgo = initDistort(stAlgo);
    case 50
        % delay based algorithms (flanger, phaser)
    case 60
        % Reverbs
    case 61
        stAlgo.ID = 61;
        stAlgo.name = 'Reverb';
        stAlgo.ProcessName = '[MetaStr.(name_str), status, data] = processReverb(data, MetaStr.(name_str));';
        stAlgo = initReverb(stAlgo);
    case 62
        stAlgo.ID = 62;
        stAlgo.name = 'RIReverb';
        stAlgo.ProcessName = '[MetaStr.(name_str), status, data] = processRIRverb(data, MetaStr.(name_str));';
        stAlgo = initRIRverb(stAlgo);
    case 70
        %
    case 80
        %
    case 100 %Restoration
        stAlgo.ID = 100;
        stAlgo.canProcessMode = [0 1 0];
        stAlgo.canInChn = 0;
        stAlgo.canOutChn = 0;
        stAlgo.name = 'DeClicker';
        stAlgo.BlockLen = 1024;
        stAlgo.ProcessName = '[MetaStr.(name_str), status, data] = processDeClicker(data, MetaStr.(name_str));';
        % Zwischenspeicherung des Ringbuffers
        stAlgo.staticFront_Middle_Back = 0;
        stAlgo.Click_Counter = 0;
        stAlgo = initDeClicker(stAlgo);

    case 101 %
        stAlgo.ID = 101;
        stAlgo.name = 'Denoiser';
        stAlgo.ProcessName = '[MetaStr.(name_str), status, data] = processDenoiser(data, MetaStr.(name_str));';
        stAlgo = initDenoiser(stAlgo);


    case 300
        % Time-Scale / Pitch-Shift algorithms
        stAlgo.ID = 300;
        stAlgo.name = 'TimeStretch';
        stAlgo.ProcessName = '[MetaStr.(name_str), status, data] = processTimeStretch(data, MetaStr.(name_str));';
        stAlgo = initTimeStretch(stAlgo);

    case 400
        %
    case 500
        %

    otherwise
        error('Algo not specified! Check initAlgo.m');
end


%--------------------------------------------------------------------------
%--------------------Licence ----------------------------------------------
% Copyright <2005> Dominik Wegmann <audioholiker@web.de>
% Permission is hereby granted, free of charge, to any person obtaining
% a copy of this software and associated documentation files
% (the "Software"), to deal in the Software without restriction, including
% without limitation the rights to use, copy, modify, merge, publish,
% distribute, sublicense, and/or sell copies of the Software, and to
% permit persons to whom the Software is furnished to do so, subject
% to the following conditions:
% The above copyright notice and this permission notice shall be included
% in all copies or substantial portions of the Software.

% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
% EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
% OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
% IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
% CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
% TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
% SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.