function stAlgo = initReverb(stAlgo)

% ******************************************************
% * Simple Reverb written by Stephen G. McGovern
% * ----------------------------------------------------


global ParaEingabe;

disp('******* Mono Reverb *******')
if (ParaEingabe == 0)
    stAlgo.n = 24;
    stAlgo.rm = [30 20 10];
    stAlgo.mic= [8 17 7];
    stAlgo.src = [20 9 2];
    stAlgo.r = 0.7;
    szOut = sprintf('Using default values, Room Dimensions: %1.1f',stAlgo.rm,'Wall absorption:%1.1f', stAlgo.r);
    disp(szOut)

else
    disp('Enter room dimensions (i.e. [18 10 5]):');
    stAlgo.rm = input('');
    disp('Enter wall reflexion (0<r<1):');
    stAlgo.r = input('');
    disp('Enter numer of mirror sources to calculate (n<96):');
    stAlgo.n = input('');
    stAlgo.mic= [stAlgo.rm].*0.3;
    stAlgo.src = [stAlgo.rm].*0.7;

end

