function stAlgo = InitPeakEQ(stAlgo)
global ParaEingabe;
disp('******* Peak EQ *******');

if (ParaEingabe == 1)
 
        stAlgo.fc = input('Center frequency [Hz]: ');
        stAlgo.Gain_dB = input('Gain [dB]: ');
        stAlgo.Q = input('Q-Factor: ');
        stAlgo.mode = input('Mode [1:RBJ,2:Zoel]: ');
else
        stAlgo.fc = 5000;
        stAlgo.Gain_dB = 12;
        stAlgo.Q = 2.7;
        stAlgo.mode = 1;
        szOut = sprintf('using default values, Gain = %1.1f dB, Freq = %1.0f Hz, Q = %1.2f, Typ = %d',...
            stAlgo.Gain_dB ,stAlgo.fc,stAlgo.Q,stAlgo.mode);
        disp(szOut);
        
end

[stAlgo.b,stAlgo.a] = getPeakCoeff(stAlgo.fs,stAlgo.fc,stAlgo.Q,stAlgo.Gain_dB,stAlgo.mode);
stAlgo.states = zeros(length(stAlgo.b)-1,1);