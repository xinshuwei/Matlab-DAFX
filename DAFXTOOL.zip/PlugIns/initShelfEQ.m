function stAlgo = initShelfEQ(stAlgo);

% * (c) IHA @ Fachhochule Oldenburg / Ostfriesland / Wilhelmshaven 
% * for the applied licence see EOF
% * written by Timm Schaer, Alexandra Mueller, Daniel Visser, Gabor Peli,
% * Ansgar Wempe
% * History
% *                 Version 0.9   Nov 2004                     FH OOW

disp('******* Shelv EQ *******');
global ParaEingabe;
if (ParaEingabe == 1)
   
        stAlgo.fc = input('Cutoff frequency [Hz]: ');
        stAlgo.Gain_dB = input('Gain [dB]: ');
        stAlgo.typ = input('Type [1:Zoelzer,2:RBJ]: ');
        stAlgo.mode = input('Mode [1:low,2:high]: ');
        %break;    
else
        stAlgo.fc = 1000;
        stAlgo.Gain_dB = -12;
        stAlgo.mode = 1;
        stAlgo.typ = 1;
        szOut = sprintf('using default values, Gain = %1.1f dB, Freq = %1.0f Hz, Type is %d and %d',...
            stAlgo.Gain_dB ,stAlgo.fc, stAlgo.mode,stAlgo.typ);
        disp(szOut);
       
end

% calculating the coefficients for the filter function
[stAlgo.b, stAlgo.a] = getShelfCoeff(stAlgo.fs,stAlgo.fc,stAlgo.Gain_dB,stAlgo.typ,stAlgo.mode);
stAlgo.states = zeros(length(stAlgo.b)-1,1);

%--------------------Licence ---------------------------------------------
% Copyright (c) <2004> Timm Schaer, Alexandra Mueller, Joerg Bitzer, 
% Daniel Visser, Ansgar Wempe, Gabor Peli
% Institute for Hearing Technology and Audiology
% University of Applied Sciences Oldenburg / Ostfriesland / Wilhelmshaven
% Permission is hereby granted, free of charge, to any person obtaining 
% a copy of this software and associated documentation files 
% (the "Software"), to deal in the Software without restriction, including 
% without limitation the rights to use, copy, modify, merge, publish, 
% distribute, sublicense, and/or sell copies of the Software, and to 
% permit persons to whom the Software is furnished to do so, subject 
% to the following conditions:
% The above copyright notice and this permission notice shall be included 
% in all copies or substantial portions of the Software.

% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
% EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES 
% OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
% IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
% CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
% TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
% SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


