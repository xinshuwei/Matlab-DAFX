function stAlgo = initRIRverb(stAlgo)

% ******************************************************
% * Convolution-Reverb, d. wegmann 07/2007
% * ----------------------------------------------------


global ParaEingabe;

disp('******* RIRverb *******')
disp('Convolution Reverb Algorithm')

path=pwd;
cd([pwd,'\PlugIns\IRs\']);

if ParaEingabe == 0
    [stAlgo.ir,stAlgo.fs] = wavread([pwd,'\Hyperverb\' 'hyperbrighthall']); %Get data and sampling rate
    disp(['Impulse Response: hyperwarmhall.wav']);
    stAlgo.mix = 0.4;
else
    [filename, pathname] = uigetfile('*.wav','Select Impulse Response');
    [stAlgo.ir,stAlgo.fs] = wavread([pathname filename]); %Get data and sampling rate
    disp(['Impulse Response: ',filename]);
    stAlgo.mix = input('Enter mix-ratio (0...1, 0=dry 1=wet):');
end
cd([path]);