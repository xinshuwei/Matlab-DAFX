function [stAlgo, status, data] = processGate(data,stAlgo)

status = 0;

he_in = fft(data);%fft of input
he_in(1:(fix(0.5*length(he_in)))) = 0;        % set negative freqs. to ZERO.
he_in(1:end-1) = he_in(1:end-1) *2;       % multiply positive samples with 2
env = abs(ifft(he_in));                   %hilbert envelope

[b,a] = butter(4,20/(stAlgo.fs/2));                    %smoothing
env2 = filter(b,a,env);
fak = max(data)/max(env2);env = env2.*fak; %normalize envelope to data level
%-----------------------------------------------------------------

offset = 850;
out =[zeros(offset,1); data];%compensate Filter delay

for n = 1:length(data)
    if (env(n)) < stAlgo.thresh*stAlgo.gatedepth
        env(n) = 0.0001;
    end
end

for n = 1:length(data)
    if (env(n)) < stAlgo.thresh
        out(n) = out(n)*(env(n));
    end
end

data = out([offset+1:length(out)],1);%cut output to original length





%--------------------------------------------------------------------------
%--------------------Licence ----------------------------------------------
% Copyright <2005> Dominik Wegmann <audioholiker@web.de>
% Permission is hereby granted, free of charge, to any person obtaining
% a copy of this software and associated documentation files
% (the "Software"), to deal in the Software without restriction, including
% without limitation the rights to use, copy, modify, merge, publish,
% distribute, sublicense, and/or sell copies of the Software, and to
% permit persons to whom the Software is furnished to do so, subject
% to the following conditions:
% The above copyright notice and this permission notice shall be included
% in all copies or substantial portions of the Software.

% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
% EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
% OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
% IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
% CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
% TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
% SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
