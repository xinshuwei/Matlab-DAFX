function [stAlgo,status,data] = processECCF(data,stAlgo)

% ******************************************************
% * Envelope Controlled EQ using Chamberlin Topology
% * ----------------------------------------------------
% * Author  :   Niklas Harlander, Dominik Wegmann
% * Date    :   Dec 2004
% * Version 1.1
% *
% * Fachhochschule OOW Standort Oldenburg
% * Studiengang H�rtechnik und Audiologie
% ******************************************************

status = 0;

for k =1:size(data,2)
    %first calculate hilbert envelope
    he_in = fft(data(:,k));                        %fft of input
    he_in((2+floor(0.5*end)):end) = 0;        % set negative freqs. to ZERO.
    he_in(1:end-1) = he_in(1:end-1) *2;       % multiply positive samples with 2
    stAlgo.env = abs(ifft(he_in));            %hilbert envelope

    [b,a] = butter(2,stAlgo.sens);
    stAlgo.env = filter(b,a,stAlgo.env);     %low-pass smoothing of envelope
    fak=1/(max(max(stAlgo.env)));
    stAlgo.env = stAlgo.env.*fak;


    %here starts the filter
    wc = pi/(stAlgo.fs);
    wc = stAlgo.fc_max*wc ;

    % stAlgo = Envelope(stAlgo, data);
    Fc = 2*sin((stAlgo.env).*wc/2);
    Qc = 1/stAlgo.Q;

    len = length(data);
    y = zeros(len,1);

    for n = 1:len

        y(n) =  data(n,k) + 2.*stAlgo.statesFIR(1) + stAlgo.statesFIR(2);

        stAlgo.statesFIR(2) = stAlgo.statesFIR(1);
        stAlgo.statesFIR(1) = data(n,k);

        data(n,k) = y(n);


        y(n) = (Fc(n)^2)*stAlgo.states(1)+(2-Fc(n)*Qc-(Fc(n)^2))*stAlgo.states(2)-(1-Fc(n)*Qc)*stAlgo.states(3);
        stAlgo.states(3) = stAlgo.states(2);
        stAlgo.states(1) = data(n,k);
        stAlgo.states(2) = y(n);

    end

    stAlgo.y = y;
    if max(max(y)) > 1
        fak=1/(max(max(stAlgo.y)));
        stAlgo.y = stAlgo.y.*fak;
    end

    data(:,k) = stAlgo.y;

end







%--------------------Licence ---------------------------------------------
% Copyright (c) <2004> Niklas Harlander, Dominik Wegmann
% Institute for Hearing Technology and Audiology
% University of Applied Sciences Oldenburg / Ostfriesland / Wilhelmshaven
% Permission is hereby granted, free of charge, to any person obtaining
% a copy of this software and associated documentation files
% (the "Software"), to deal in the Software without restriction, including
% without limitation the rights to use, copy, modify, merge, publish,
% distribute, sublicense, and/or sell copies of the Software, and to
% permit persons to whom the Software is furnished to do so, subject
% to the following conditions:
% The above copyright notice and this permission notice shall be included
% in all copies or substantial portions of the Software.

% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
% EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
% OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
% IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
% CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
% TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
% SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.




