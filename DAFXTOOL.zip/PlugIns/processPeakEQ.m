function [stAlgo, status, data] = processPeakEQ(data, stAlgo)

% *************************************************************************
% * (c) IHA @ Fachhochule Oldenburg / Ostfriesland / Wilhelmshaven 
% * for the applied licence see EOF
% * written by Timm Schaer, Alexandra Mueller, Daniel Visser, Ansgar Wempe,
% * Gabor Peli
% * History
% *                 Version 0.9   Nov 2004                     FH OOW
% *************************************************************************

% wenn Status =0, dann wurde Algo erfolgreich durchgefuehrt
status = 0;
[data,stAlgo.states] = filter(stAlgo.b, stAlgo.a,data,stAlgo.states);