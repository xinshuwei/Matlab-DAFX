function stAlgo = initGain(stAlgo)

% ******************************************************
% * Gain Controller *** boosts/attenuates signal +/-24dB
% * ----------------------------------------------------
% * Author  :   Dominik Wegmann
% * Date    :   Dec 2004
% * Version 1.1
% *
% * Fachhochschule OOW Standort Oldenburg
% * Studiengang H�rtechnik und Audiologie
% ******************************************************
 
global ParaEingabe;

disp('******* Gain Control *******');
if (ParaEingabe == 0)
    stAlgo.gain_db = -6; %default
    szOut = sprintf('Using default values, Gain = %1.2f dB',stAlgo.gain_db);
    disp(szOut);
else    
   disp('Enter cut/boost in dB:');
   stAlgo.gain_db = input('');
      while(stAlgo.gain_db < -30 || stAlgo.gain_db > 30)
           disp('boost/cut-range is limited to +/- 30db!');
           disp('cut/boost in dB:');
           stAlgo.gain_db = input('');
       end
 end

stAlgo.gain_lin = 10^(stAlgo.gain_db/20);


