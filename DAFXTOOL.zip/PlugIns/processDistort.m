function [stAlgo, status, data] = processDistort(data, stAlgo)

status = 0;

k = 1.3*stAlgo.dist/(1.0001-stAlgo.dist);
data = (1+k)*(data)./(1+k*abs(data)); 
q=data*3*stAlgo.dist/max(abs(data));
z=sign(-q).*(1-exp(sign(-q).*q));
y=z*max(abs(data))/max(abs(z));
data=y;
data=data.*(1/max(max(data)));