clear 

close all;

%[signal,fs] = wavread('');
[signal,fs] = wavread('groovloop.wav');


Gain_dB = 12;

Gain = 10^(Gain_dB/20);

% Direct Clipping

ClipSignal = signal.*Gain;
idx = find(ClipSignal >=1);
ClipSignal(idx) = 1;
idx = find(ClipSignal <-1);
ClipSignal(idx) = -1;


% Soft-Clipping

NewGain = Gain/1.7;

SoftClipSignal = NewGain.*signal;

idx = find(SoftClipSignal >=1);
SoftClipSignal(idx) = 1;
idx = find(SoftClipSignal <-1);
SoftClipSignal(idx) = -1;

idx = find (SoftClipSignal < 1 & SoftClipSignal >=-1);
SoftClipSignal(idx) = 1.5*SoftClipSignal(idx)-1/2.*SoftClipSignal(idx).*SoftClipSignal(idx).*SoftClipSignal(idx);

figure();plot(ClipSignal);

hold on;
plot(SoftClipSignal,'r');

%wavwrite(ClipSignal,fs,16,'d:\audio\Comptest\ClipSoloGesang');
%wavwrite(SoftClipSignal,fs,16,'d:\audio\Comptest\SoftClipTestSoloGesang');







