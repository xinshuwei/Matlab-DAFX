function dafxtool(a)
% ******************************************************
% * DAFXTOOL V2.1
% * signal processing and visualization toolbox, inspired by lectures on
% * Digital Audio Effects at Institute for Hearing Technology and Audiology
% * University of Applied Sciences Oldenburg, Germany
% * ----------------------------------------------------
% * Author  :   Dominik Wegmann <audioholiker@web.de>
% * Date    :   10/2005
% * Last modified: July-16-2007
% *******************************************************
% * NOT ALL OF THE FREAKY STUFF YOU�LL FIND IN SOME FUNCTIONS IS MY WORK!
% * REQUIRES MATLAB 7+ !!!
% * Check included readme.txt for further notes!
% *******************************************************

global H_DAFX F_DAFX STATBOX STATUSTEXT PLUGINS FXNAME FXID data Output fs nbits %set global variables

%Insert new effects and corresponding FX-IDs here! (specified in initAlgo.m)
FXNAME={'select|Gain Controller|Shelving EQ|Peak(Bell) EQ|Envelope Controlled Filter|Peak-Clipper|Noise Gate|Distortion|Time Scaler|Denoiser|Reverb|RIRverb'};%Available PlugIns
FXID=[0 1 11 10 12 30 32 40 300 101 61 62];  %FXNAME-assigned IDs (=>initAlgo.m). place the ID at the correct position within the matrix!

if nargin == 0
    a = 0;
end

switch a

    case 0 % draw the GUI

        addpath([pwd,'\PlugIns']);%Add PlugIn-Folder
        addpath([pwd,'\Functions']);%Add function-Folder
        clear global data  % erase any previously used data

        drawthegui(FXNAME); %Draws main GUI

        %------------------------------------------------------------------
        %GUI-control actions:

    case 1 % record button
        global micrecorder

        fs = get(H_DAFX(6),'String');fs=str2num(fs);
        nbits=get(H_DAFX(8),'String');nbits=str2num(nbits);

        set(H_DAFX(31),'Visible','on');
        set(H_DAFX(31),'Enable','on');
        set(H_DAFX(1),'Visible','off');
        set(H_DAFX(1),'Enable','off');
        text=['Recording...'];addtext(text);

        micrecorder = audiorecorder(fs,nbits,1); %initialize recorder
        record(micrecorder); %recording data


    case 2  % Play Input
        global player
        startsampl = get(H_DAFX(21),'Value');startsampl=round(startsampl); %get slider positions
        endsampl = get(H_DAFX(22),'Value');endsampl=round(endsampl);

        text=['Play...'];addtext(text);
        set(H_DAFX(28),'Visible','on');
        set(H_DAFX(28),'Enable','on');
        set(H_DAFX(2),'Visible','off');
        set(H_DAFX(2),'Enable','off');

        chn=1; %channel selection
        if min(size(data)) > 1
            channel=get(H_DAFX(26),'Value');
            switch channel
                case 1
                    chn=[1 2];
                case 2
                    chn=1;
                case 3
                    chn=2;
            end
        end
        player = audioplayer(data(:,chn),fs,nbits); %initialize player
        loop = get(H_DAFX(38),'Value');
        %         h_axe = get(F_DAFX, 'CurrentAxes');
        %         updateplaycursor(h_axe, player,(startsampl/fs));
        play(player,[startsampl endsampl]);%playback
        pause((endsampl-startsampl)/fs);
        while loop == 1
            play(player,[startsampl endsampl]);
            %updateplaycursor(h_axe, player, startsampl);
            pause(0.001);
            loop = get(H_DAFX(38),'Value');
        end
        set(H_DAFX(28),'Visible','off');
        set(H_DAFX(28),'Enable','off');
        set(H_DAFX(2),'Visible','on');
        set(H_DAFX(2),'Enable','on');


    case 3  %Play Output
        global player
        startsampl = get(H_DAFX(21),'Value');startsampl=round(startsampl);
        endsampl = get(H_DAFX(22),'Value');endsampl=round(endsampl);

        set(H_DAFX(30),'Visible','on');
        set(H_DAFX(30),'Enable','on');
        set(H_DAFX(20),'Visible','off');
        set(H_DAFX(20),'Enable','off');
        chn=1;
        if min(size(Output)) > 1
            channel=get(H_DAFX(26),'Value');
            switch channel
                case 1
                    chn=[1 2];
                case 2
                    chn=1;
                case 3
                    chn=2;
            end
        end

        if length(Output) ~= length(data)
            startsampl = 1; endsampl = length(Output);
        end

        player = audioplayer(Output(:,chn),fs,nbits);
        play(player,[startsampl endsampl]);

        text=['Play Output...'];addtext(text);
        pause((endsampl-startsampl)/fs);
        set(H_DAFX(30),'Visible','off');
        set(H_DAFX(30),'Enable','off');
        set(H_DAFX(20),'Visible','on');
        set(H_DAFX(20),'Enable','on');

    case 4 %Load button

        [filename, pathname] = uigetfile('*.wav','Select Audiofile');
        set(H_DAFX(12),'String',[filename]);
        set(H_DAFX(16),'Value',1);

        if filename ~= 0
            text=['Loading data...'];addtext(text);

            %             fextension = filename(end-3:end);
            %
            %             switch fextension
            %                 case '.wav'
            [data,fs,nbits] = wavread([pathname filename]); %Get data and sampling rate


            %                 case '.mat'
            %                     load([pathname,filename]);%Get data
            %
            %                 otherwise
            %                     error(['--> Unsupported Input File Format: "', filename, '" <--']);
            %             end

            set(H_DAFX(26),'Value',1);
            set(H_DAFX(26),'String','1');
            set(H_DAFX(26),'enable','off');
            if min(size(data)) > 1
                chanselect={'1+2|1|2'};
                text=['loading stereo data...'];addtext(text);
                set(H_DAFX(26),'Enable','on');
                set(H_DAFX(26),'String',char(chanselect));
            end
            set(H_DAFX(26),'Visible','on');

            datalen=length(data);
            startsampl=1;
            endsampl=max(datalen);

            set(H_DAFX(21),'Max',max(datalen)); %set region sliders
            set(H_DAFX(21),'Min',1);
            set(H_DAFX(21),'Value',1);
            set(H_DAFX(22),'Max',max(datalen));
            set(H_DAFX(22),'Min',1);
            set(H_DAFX(22),'Value',max(datalen));
            set(H_DAFX(6),'String',num2str(fs));  %Set data fields
            set(H_DAFX(8),'String',num2str(nbits));
            set(H_DAFX(3),'String',[num2str(length(data)/fs)]);
            set(H_DAFX(16),'Visible','on'); %Make buttons available
            set(H_DAFX(18),'Visible','on');
            set(H_DAFX(19),'Visible','on');
            set(H_DAFX(21),'Visible','on');
            set(H_DAFX(22),'Visible','on');
            set(H_DAFX(27),'Visible','off');
            set(H_DAFX(32),'Visible','on');
            set(H_DAFX(33),'Visible','on');
            set(H_DAFX(34),'Visible','on');
            set(H_DAFX(35),'Visible','off');
            set(H_DAFX(36),'Visible','on');
            set(H_DAFX(37),'Visible','off');
            set(H_DAFX(37),'enable','off');


            undock = 0;
            timedata(F_DAFX,data,fs,0.05,0.52,0.69,0.32,undock);% displays the time graph of the signal

            if isempty(Output)== 0
                Output=[0];
                figure(F_DAFX);
                H = subplot('position',[0.05 0.10 0.69 0.32]);
                plot(Output);
                set(H,'Visible','off');
                set(H_DAFX(17),'Visible','off');
                set(H_DAFX(14),'Visible','off');
            end

            rmsdata = 20*log10(abs(norm(data)/sqrt(length(data))));
            %rmsdata = 20*log10(sqrt(mean(data.^2)));
            maxdata = 20*log10(((max(abs(data)))));
            mindata = 20*log10(((min(abs(nonzeros(data))))));
            set(STATBOX(5),'String',[num2str(rmsdata)]);
            set(STATBOX(8),'String',[num2str(maxdata)]);
            set(STATBOX(11),'String',[num2str(mindata)]);
            set(STATBOX(6),'String','---');
            set(STATBOX(9),'String','---');
            set(STATBOX(12),'String','---');
            text=['...done.'];addtext(text);

        end

    case 5 % Save data to wavefile

        [filename, pathname] = uiputfile('*.wav;*.mat', 'Save Data to *.wav');
        if filename ~= 0

            fextension = filename(end-3:end);

            switch fextension
                case '.wav'
                    wavwrite(Output,fs,[pathname filename]);

                case '.mat'
                    save([pathname,filename],'Output');%save data data
                otherwise
                    error(['--> Unsupported Input File Format: "', filename, '" <--']);
            end

            text=['Saving data... '];addtext(text);
            text=['...done. '];addtext(text);
        end



    case 8 %set input view

        channel = get(H_DAFX(26),'Value');%get selected channel
        if min(size(data)) == 1
            chn=1;
        else
            switch channel
                case 1
                    chn=[1 2];
                case 2
                    chn=1;
                case 3
                    chn=2;

            end
        end
        dat = data(:,chn);
        undock = get(H_DAFX(36),'Value');
        view = get(H_DAFX(16),'Value');
        plotdata(F_DAFX,dat,fs,view,0.05,0.52,0.69,0.32,undock) %plot the signal


    case 9    %set output view

        channel = get(H_DAFX(27),'Value');%get selected channel
        if min(size(Output)) == 1
            chn=1;
        else
            switch channel
                case 1
                    chn=[1 2];
                case 2
                    chn=1;
                case 3
                    chn=2;

            end
        end
        out = Output(:,chn);
        undock = get(H_DAFX(37),'Value');
        view = get(H_DAFX(17),'Value');
        plotdata(F_DAFX,out,fs,view,0.05,0.10,0.69,0.32,undock) %plot the signal



    case 10   %Process data

        global ParaEingabe

        text=['Processing data... '];addtext(text);
        set(H_DAFX(15),'FontAngle','italic');
        pause(0.001);


        a_ID=[];
        fx1=get(PLUGINS(2),'Value');     %set PlugIn-IDs
        a_ID(1)=FXID(fx1);

        fx2=get(PLUGINS(3),'Value');
        a_ID(2)=FXID(fx2);

        fx3=get(PLUGINS(4),'Value');
        a_ID(3)=FXID(fx3);

        fx4=get(PLUGINS(5),'Value');
        a_ID(4)=FXID(fx4);

        fx5=get(PLUGINS(6),'Value');
        a_ID(5)=FXID(fx5);


        startsampl = get(H_DAFX(21),'Value');startsampl=round(startsampl);
        endsampl = get(H_DAFX(22),'Value');endsampl=round(endsampl);
        region = get(PLUGINS(8),'Value');


        if a_ID == 0
            Output = data;
            if region ==1
                Output = data([startsampl:endsampl],:);
            end
            text=['...done. '];addtext(text);

        else

            ParaEingabe=get(PLUGINS(7),'Value');
            if ParaEingabe == 1
                ParaEingabe = 0;
            else
                ParaEingabe = 1;
            end

            chn=1; %channel selection
            if min(size(data)) > 1
                channel=get(H_DAFX(26),'Value');
                switch channel
                    case 1
                        chn=[1 2;]
                        text=('Processing stereo data');addtext(text);
                        %
                    case 2
                        chn=1;
                    case 3
                        chn=2;
                end
            end

            t = clock;
            Output = fxprocessing(data([startsampl:endsampl],chn),fs,nbits,a_ID,ParaEingabe);%launching plugin processing application

            switch region
                case 0
                    if length(Output) ~= length(data)
                        if startsampl == 1
                            Output = [Output(:,chn); data([endsampl+1:length(data)],chn)];
                        elseif endsampl == length(data)
                            Output = [data([1:startsampl-1],chn); Output(:,chn)];
                        else
                            Output = [data([1:startsampl-1],chn); Output(:,chn); data([endsampl+1:length(data)],chn)];
                        end
                    end
                case 1
                    Output = Output;
            end

            text=['...done. '];addtext(text);

        end
        undock = 0;
        timedata(F_DAFX,Output,fs,0.05,0.10,0.69,0.32,undock);

        chan=min(size(Output));
        set(H_DAFX(27),'String','1');
        set(H_DAFX(27),'Enable','off');
        set(H_DAFX(27),'Visible','on');
        if chan > 1
            chanselect={'1+2|1|2'};
            set(H_DAFX(27),'Value',1);
            set(H_DAFX(27),'Enable','on');
            set(H_DAFX(27),'String',char(chanselect));
        end
        set(H_DAFX(27),'Visible','on');

        rmsdata = 20*log10(abs(norm(Output)/sqrt(length(data))));
        maxdata = 20*log10((max(abs(Output))));
        mindata = 20*log10((min(abs(nonzeros(Output)))));
        set(STATBOX(6),'String',[num2str(rmsdata)]);
        set(STATBOX(9),'String',[num2str(maxdata)]);
        set(STATBOX(12),'String',[num2str(mindata)]);
        set(H_DAFX(15),'FontAngle','normal');
        set(H_DAFX(10),'enable','on');
        set(H_DAFX(20),'enable','on');
        set(H_DAFX(14),'Visible','on');
        set(H_DAFX(17),'Visible','on');
        set(H_DAFX(17),'Value',1);
        set(H_DAFX(35),'Visible','on');
        set(H_DAFX(37),'Visible','on');
        set(H_DAFX(37),'enable','on');
        set(H_DAFX(43),'Visible','on');
        set(H_DAFX(43),'enable','on');

        %whos


    case 20 %select input channel to view
        channel = get(H_DAFX(26),'Value');%select channel
        switch channel
            case 1
                chn=[1 2];
            case 2
                chn=1;
            case 3
                chn=2;
        end
        dat = data(:,chn);
        undock = get(H_DAFX(36),'Value');
        view = get(H_DAFX(16),'Value');
        plotdata(F_DAFX,dat,fs,view,0.05,0.52,0.69,0.32,undock) %plot the signal


    case 21
        channel = get(H_DAFX(27),'Value');  %select output channel view
        switch channel
            case 1
                chn=[1 2];
            case 2
                chn=1;
            case 3
                chn=2;
        end
        out=Output(:,chn);
        undock=get(H_DAFX(37),'Value');
        view = get(H_DAFX(17),'Value');
        plotdata(F_DAFX,out,fs,view,0.05,0.10,0.69,0.32,undock) %plot the signal


    case 30  %Stop playback

        global player
        stop(player);
        set(H_DAFX(38),'Value',0);
        set(H_DAFX(28),'Visible','off');
        set(H_DAFX(28),'Enable','off');
        set(H_DAFX(2),'Visible','on');
        set(H_DAFX(2),'Enable','on');
        set(H_DAFX(30),'Visible','off');
        set(H_DAFX(30),'Enable','off');
        set(H_DAFX(20),'Visible','on');
        set(H_DAFX(20),'Enable','on');

    case 31 %Stop recording

        global micrecorder

        stop(micrecorder);
        data = getaudiodata(micrecorder);%get the recorded data

        set(H_DAFX(31),'Visible','off');
        set(H_DAFX(31),'Enable','off');
        set(H_DAFX(1),'Visible','on');
        set(H_DAFX(1),'Enable','on');
        text=['recording stopped.'];addtext(text);
        undock = 0;
        timedata(F_DAFX,data,fs,0.05,0.52,0.69,0.32,undock);% displays time graph of the recorded signal

        datalen=length(data);
        startsampl=1;
        endsampl=max(datalen);

        set(H_DAFX(21),'Max',max(datalen)); %set region sliders
        set(H_DAFX(21),'Min',1);
        set(H_DAFX(21),'Value',1);
        set(H_DAFX(22),'Max',max(datalen));
        set(H_DAFX(22),'Min',1);
        set(H_DAFX(22),'Value',max(datalen));
        set(H_DAFX(6),'String',num2str(fs));  %Set data fields
        set(H_DAFX(8),'String',num2str(nbits));
        set(H_DAFX(3),'String',num2str(datalen/fs));
        set(H_DAFX(10),'enable','on');  %Make buttons available
        set(H_DAFX(15),'enable','on');
        set(H_DAFX(16),'Visible','on');
        set(H_DAFX(16),'Value',1);
        set(H_DAFX(18),'Visible','on');
        set(H_DAFX(19),'Visible','on');
        set(H_DAFX(21),'Visible','on');
        set(H_DAFX(22),'Visible','on');
        set(H_DAFX(26),'Enable','off');
        set(H_DAFX(26),'Value',1);
        set(H_DAFX(26),'String','1');
        set(H_DAFX(26),'Visible','on');
        set(H_DAFX(34),'Visible','on');
        set(H_DAFX(36),'Visible','on');

        rmsdata = 20*log10(abs(norm(data)/sqrt(length(data))));
        maxdata = 20*log10((max(abs(data))));
        mindata = 20*log10((min(abs(nonzeros(data)))));
        set(STATBOX(5),'String',[num2str(rmsdata)]);
        set(STATBOX(8),'String',[num2str(maxdata)]);
        set(STATBOX(11),'String',[num2str(mindata)]);

    case 32 %Signalgenerator

        data = sigs;%launch signal generator

        fs = 44100;nbits=16;
        undock=0;
        timedata(F_DAFX,data,fs,0.05,0.52,0.69,0.32,undock);% displays the time graph of the signal

        datalen=length(data);
        startsampl=1;
        endsampl=max(datalen);
        rmsdata = 20*log10(abs(norm(data)/sqrt(length(data))));
        maxdata = 20*log10(max(abs(data)));
        mindata = 20*log10(min(abs(nonzeros(data))));
        set(STATBOX(5),'String',[num2str(rmsdata)]);
        set(STATBOX(8),'String',[num2str(maxdata)]);
        set(STATBOX(11),'String',[num2str(mindata)]);
        set(H_DAFX(21),'Max',max(datalen)); %set region sliders
        set(H_DAFX(21),'Min',1);
        set(H_DAFX(21),'Value',1);
        set(H_DAFX(22),'Max',max(datalen));
        set(H_DAFX(22),'Min',1);
        set(H_DAFX(22),'Value',max(datalen));
        set(H_DAFX(21),'Visible','on');
        set(H_DAFX(22),'Visible','on');
        set(H_DAFX(32),'Visible','on');
        set(H_DAFX(33),'Visible','on');
        set(H_DAFX(6),'String',num2str(fs));  %Set data fields
        set(H_DAFX(8),'String',num2str(nbits));
        set(H_DAFX(3),'String',num2str(datalen/fs));
        set(H_DAFX(16),'Enable','on');
        set(H_DAFX(16),'Visible','on');%Make buttons available
        set(H_DAFX(16),'Value',1);
        set(H_DAFX(26),'Value',1);
        set(H_DAFX(26),'String','1');
        set(H_DAFX(26),'enable','off');
        set(H_DAFX(34),'Visible','on');
        set(H_DAFX(36),'Visible','on');
        set(H_DAFX(15),'enable','on');
        set(H_DAFX(10),'enable','on');
        set(H_DAFX(20),'enable','on');


    case 33 %crop
        global temp;
        temp = data;
        startsampl = get(H_DAFX(21),'Value');startsampl=round(startsampl);
        endsampl = get(H_DAFX(22),'Value');endsampl=round(endsampl);
        data = [data([1:startsampl],:); data([endsampl:length(data)],:)];
        view = get(H_DAFX(16),'Value');
        plotdata(F_DAFX,data,fs,view,0.05,0.52,0.69,0.32,0);
        set(H_DAFX(21),'Max',max(length(data))); %reset region sliders
        set(H_DAFX(21),'Min',1);
        set(H_DAFX(21),'Value',1);
        set(H_DAFX(22),'Max',max(length(data)));
        set(H_DAFX(22),'Min',1);
        set(H_DAFX(22),'Value',max(length(data)));

    case 34 %fade in
        global temp;
        temp = data;
        startsampl = get(H_DAFX(21),'Value');startsampl=round(startsampl);
        endsampl = get(H_DAFX(22),'Value');endsampl=round(endsampl);
        fade = linspace(0,1,endsampl-startsampl+1);
        chn = 1;
        if size(data,2)>1
            channel = get(H_DAFX(26),'Value');%select channel

            switch channel
                case 1
                    data([startsampl:endsampl],1) = data([startsampl:endsampl],1).* fade';
                    data([startsampl:endsampl],2) = data([startsampl:endsampl],2).* fade';
                    chn = [1 2];
                case 2
                    chn = [1];
                    data([startsampl:endsampl],1) = data([startsampl:endsampl],1).* fade';
                case 3
                    chn = [2];
                    data([startsampl:endsampl],2) = data([startsampl:endsampl],2).* fade';
            end
        else
            data([startsampl:endsampl],1) = data([startsampl:endsampl],1).* fade';

        end

        view = get(H_DAFX(16),'Value');
        plotdata(F_DAFX,data(:,chn),fs,view,0.05,0.52,0.69,0.32,0);
        plotlines(F_DAFX,data,fs,0.05,0.52,0.69,0.32,startsampl,endsampl,view);

    case 35 %fade out
        global temp;
        temp = data;
        startsampl = get(H_DAFX(21),'Value');startsampl=round(startsampl);
        endsampl = get(H_DAFX(22),'Value');endsampl=round(endsampl);
        fade = linspace(1,0,endsampl-startsampl+1);
        chn = 1;
        if size(data,2)>1
            channel = get(H_DAFX(26),'Value');%select channel

            switch channel
                case 1
                    data([startsampl:endsampl],1) = data([startsampl:endsampl],1).* fade';
                    data([startsampl:endsampl],2) = data([startsampl:endsampl],2).* fade';
                    chn = [1 2];
                case 2
                    data([startsampl:endsampl],1) = data([startsampl:endsampl],1).* fade';
                    chn = [1];
                case 3
                    data([startsampl:endsampl],2) = data([startsampl:endsampl],2).* fade';
                    chn = [2];
            end
        else
            data([startsampl:endsampl],1) = data([startsampl:endsampl],1).* fade';
        end
        view = get(H_DAFX(16),'Value');
        plotdata(F_DAFX,data(:,chn),fs,view,0.05,0.52,0.69,0.32,0);
        plotlines(F_DAFX,data,fs,0.05,0.52,0.69,0.32,startsampl,endsampl,view);

    case 36
        global temp; %undo
        data = temp;

        view = get(H_DAFX(16),'Value');
        plotdata(F_DAFX,data,fs,view,0.05,0.52,0.69,0.32,0);
        set(H_DAFX(21),'Max',max(length(data))); %reset region sliders
        set(H_DAFX(21),'Min',1);
        set(H_DAFX(21),'Value',1);
        set(H_DAFX(22),'Max',max(length(data)));
        set(H_DAFX(22),'Min',1);
        set(H_DAFX(22),'Value',max(length(data)));

    case 37 %Flip output to input button

        data = Output;

        datalen=length(data);
        startsampl=1;
        endsampl=max(datalen);
        set(H_DAFX(21),'Max',max(datalen)); %set region sliders
        set(H_DAFX(21),'Min',1);
        set(H_DAFX(21),'Value',1);
        set(H_DAFX(22),'Max',max(datalen));
        set(H_DAFX(22),'Min',1);
        set(H_DAFX(22),'Value',max(datalen));
        set(H_DAFX(6),'String',num2str(fs));  %Set data fields
        set(H_DAFX(8),'String',num2str(nbits));
        set(H_DAFX(3),'String',[num2str(length(data)/fs)]);

        rmsdata = 20*log10(abs(norm(data)/sqrt(length(data))));
        maxdata = 20*log10((max(abs(data))));
        mindata = 20*log10((min(abs(nonzeros(data)))));
        set(STATBOX(5),'String',[num2str(rmsdata)]);
        set(STATBOX(8),'String',[num2str(maxdata)]);
        set(STATBOX(11),'String',[num2str(mindata)]);

        undock = 0;
        timedata(F_DAFX,data,fs,0.05,0.52,0.69,0.32,undock);% displays the time graph of the signal



    case 40 %Helpbutton
        open Readme.txt;

    case 100 %region slider markers

        startsampl = get(H_DAFX(21),'Value');startsampl=round(startsampl);
        endsampl = get(H_DAFX(22),'Value');endsampl=round(endsampl);
        view = get(H_DAFX(16),'Value');
        line_handle = findobj(gca,'LineStyle',':','Color','r');
        if exist('line_handle')==1
            delete(line_handle);
        end
        plotlines(F_DAFX,data,fs,0.05,0.52,0.69,0.32,startsampl,endsampl,view);%plot region markers




end

%EOF dafxtool.m


%--------------------------------------------------------------------------
%--------------------Licence ----------------------------------------------
% Copyright <2005> Dominik Wegmann <audioholiker@web.de>
% Permission is hereby granted, free of charge, to any person obtaining
% a copy of this software and associated documentation files
% (the "Software"), to deal in the Software without restriction, including
% without limitation the rights to use, copy, modify, merge, publish,
% distribute, sublicense, and/or sell copies of the Software, and to
% permit persons to whom the Software is furnished to do so, subject
% to the following conditions:
% The above copyright notice and this permission notice shall be included
% in all copies or substantial portions of the Software.

% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
% EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
% OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
% IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
% CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
% TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
% SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
