function H = phasedata(Fig,dat,fs,left,bottom,width,height,undock)

fftlen = 2048;

Y = fft(dat(:,1),fftlen);
f = (0:fftlen/2-1)*fs/fftlen;
f = (0:fftlen-1)*fs/fftlen;

if undock == 0
    figure(Fig);
    H = subplot('position',[left bottom width height]);
    set(H,'FontSize',8);

else
    figure()
end
plot(f,unwrap(angle(Y))*180/pi);
ylabel('Phase');xlabel('Frequency [Hz]'); grid on;