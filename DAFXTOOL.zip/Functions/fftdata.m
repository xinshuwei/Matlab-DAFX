function H = fftdata(Fig,dat,fs,left,bottom,width,height,undock)


winlen = 2048;
fftlen = 2*winlen;
len = length(dat);
w = hamming(winlen)';
a = ceil(length(dat)/winlen)*winlen;
dat = [dat;zeros(a-length(dat),1)];%zero-padding
len = length(dat);
n = 1;
pos=1;                                          
while (pos+winlen <= len)
    frame = dat((pos:pos+winlen-1),1).*w'; %windowing
    pos = pos + winlen/2; %50% overlap
    Y(n,:) = fft(frame,fftlen);
    n = n+1;
end
Y = sum(Y)/n;
Y(Y == 0) = 1e-17;
fftdat=20*log10(abs(Y(1:fftlen/2))+eps);

f = (0:fftlen/2-1)*fs/fftlen;


mini = min(min(fftdat));
if  mini < -120
    mini = -120;
end

if undock == 0
    figure(Fig);
    H = subplot('position',[left bottom width height]);
    set(H,'FontSize',8);

else
    figure()
end
plot(f,fftdat);
axis([10 fs/2 mini max(max(fftdat))+1]);ylabel('Magnitude [dB]');xlabel('Frequency [Hz]'); grid on;hold on;


if min(size(dat))== 2
    n = 1;
    pos=1;                                           %windowing
    while (pos+winlen <= len)
        frame = dat((pos:pos+winlen-1),2).*w';
        pos = pos + winlen; %0% overlap
        Y(n,:) = fft(frame,fftlen);
        n = n+1;
    end

    Y = sqrt(sum(Y));
    fftdat=20*log10(abs(Y(1:fftlen/2))+eps);
    plot(f,fftdat,'g');
end
hold off;
