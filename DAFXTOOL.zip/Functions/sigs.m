function y = sigs;
%Signalgenerator
disp('******** SIGNALGENERATOR *********')
disp('Choose: 1:Sinus 2:Pink Noise 3:White Noise');
disp('        4:Sweep_lin 5:Sweep_log 6:Sweep_square');
disp('        7:Dirac 8:Custom');
sigtype = input('');

if sigtype == 7
    y = zeros(1,512);
    y(256) = 1;
elseif sigtype == 8
    y = input('Your signal: y =');

else

    len = input('Length of signal (sec.):');
    A = input('Amplitude (0...1):');
    fs = 44100;
    t = 0:1/fs:len;

    switch sigtype
        case 1
            f = input('Frequency(Hz):');
            y = A.*sin(2*pi*f*t);
        case 4
            f = input('Min Frequency(Hz):');
            fmax = input('Max Frequency(Hz):');
            y = A.*chirp(t,f,len,fmax);
        case 5
            f = input('Min Frequency(Hz):');
            fmax = input('Max Frequency(Hz):');
            y = A.*chirp(t,f,len,fmax,'logarithmic');
        case 6
            f = input('Min Frequency(Hz):');
            fmax = input('Max Frequency(Hz):');
            y = A.*chirp(t,f,len,fmax,'q');

        case 2
            y = noise([1 (fs*len)],-1);
            fac = A/max(max(y));y = y.*fac;
        case 3
            y = noise([1 (fs*len)],0);
            fac = A/max(max(y));y = y.*fac;

    end
end

y = y';
%fi = linspace(0,1,96);
%y([1:96],:)=y([1:96],:).*fi';

%---------------SUBFUNCTION-------------------------------
function x = noise(DIM,BETA),
% function x = spatialPattern(DIM, BETA),
%
% This function generates 1/f spatial noise, with a normal error
% distribution (the grid must be at least 10x10 for the errors to be normal).
% 1/f noise is scale invariant, there is no spatial scale for which the
% variance plateaus out, so the process is non-stationary.
%
%     DIM is a two component vector that sets the size of the spatial pattern
%           (DIM=[10,5] is a 10x5 spatial grid)
%     BETA defines the spectral distribution.
%          Spectral density S(f) = N f^BETA
%          (f is the frequency, N is normalisation coeff).
%               BETA = 0 is random white noise.
%               BETA  -1 is pink noise
%               BETA = -2 is Brownian noise
%          The fractal dimension is related to BETA by, D = (6+BETA)/2

% Written by Jon Yearsley  1 May 2004
%     j.yearsley@macaulay.ac.uk

% Generate the grid of frequencies. u is the set of frequencies along the
% first dimension
% First quadrant are positive frequencies.  Zero frequency is at u(1,1).
u = [(0:floor(DIM(1)/2)) -(ceil(DIM(1)/2)-1:-1:1)]'/DIM(1);
% Reproduce these frequencies along ever row
u = repmat(u,1,DIM(2));
% v is the set of frequencies along the second dimension.  For a square
% region it will be the transpose of u
v = [(0:floor(DIM(2)/2)) -(ceil(DIM(2)/2)-1:-1:1)]/DIM(2);
% Reproduce these frequencies along ever column
v = repmat(v,DIM(1),1);

% Generate the power spectrum
S_f = (u.^2 + v.^2).^(BETA/2);

% Set any infinities to zero
S_f(S_f==inf) = 0;

% Generate a grid of random phase shifts
phi = rand(DIM);

% Inverse Fourier transform to obtain the the spatial pattern
x = ifft2(S_f.^0.5 .* (cos(2*pi*phi)+i*sin(2*pi*phi)));

% Pick just the real component
x = real(x);








