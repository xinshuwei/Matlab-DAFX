function H = psddata(Fig,dat,fs,left,bottom,width,height,undock)

if undock == 0
    figure(Fig);
    H = subplot('position',[left bottom width height]);
    set(H,'FontSize',8);
else
    figure()
end

psd(dat(:,1))
hold on;

if min(size(dat))== 2
    psd(dat(:,2))
end

hold off;
set(gca,'XTickLabel',{'0';num2str(0.1*fs/2);num2str(0.2*fs/2);num2str(0.3*fs/2);num2str(0.4*fs/2);num2str(0.5*fs/2); ...
    num2str(0.6*fs/2);num2str(0.7*fs/2);num2str(0.8*fs/2);num2str(0.9*fs/2);num2str(fs/2)});
ylabel('Power Spectrum Magnitude [dB]');xlabel('Frequency [Hz]');title(''); grid on;
