function H = watrfdata(Fig,dat,fs,left,bottom,width,height,undock)

if length(dat)<44101
    fftlen=512;
    step=128;
end

if length(dat)>=44101 && length(dat)<240000
    fftlen=1024;
    step=512;
end

if length(dat)>=240000
    fftlen=2048;
    step=1024;
end

win = hamming(step);
kk=1;
pos=1;                                          
while (pos+step <= length(dat))   %start blockprocessing
    frame = dat([pos:pos+step-1],1);
    frame = frame.*win;    %windowing
    Fdat(kk,:)=20*log10(abs(fft(frame,fftlen)))+eps;
    pos = pos + step/2; %50% overlap
    kk=kk+1;
end

f = 0:fs/fftlen:fs/2 - fs/fftlen;
t = (0:(step/2)/fs:((kk)*step/2)/fs-step/fs);
minZ=-120;
Zmin=min(min(Fdat));
if Zmin<minZ
    Zmin=minZ;
end

if undock == 0
    figure(Fig);
    H = subplot('position',[left bottom width height]);
    set(H,'FontSize',8);
else
    figure()
end
mesh(f(1:fftlen/2),t,(Fdat(:,1:fftlen/2)));view(40,65);
% waterfall(f(1:fftlen/2),t,(Fdat(:,1:fftlen/2)));view(40,55);
set(gca,'YDir','reverse');colormap('jet');
set(gca,'XLim',[0 fs/2]);
set(gca,'ZLim',[Zmin max(max(Fdat))]);
xlabel('Frequency [Hz]');ylabel('Time [s]');zlabel('Magnitude [dB]');


