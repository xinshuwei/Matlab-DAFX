function H = timedata(Fig,dat,fs,left,bottom,width,height,undock)



datlen = length(dat)/fs;
delta_t = 1/fs;
t = 0:delta_t:(datlen-delta_t);
if undock == 0
    figure(Fig);
    H = subplot('position',[left bottom width height]);set(H,'FontSize',8);
else
    figure()
end
plot(t,dat(:,1)), xlabel('Time [sec]'), ylabel('Amplitude');
axis([0 datlen min(min(dat))-0.01 max(max(dat))+0.01]);set(gca,'YGrid','on');
hold on;

if min(size(dat)) > 1
    plot(t,dat(:,2),'g:')
end
hold off;