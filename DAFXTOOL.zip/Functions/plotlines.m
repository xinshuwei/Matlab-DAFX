function H = plotlines(Fig,data,fs,left,bottom,width,height,startsampl,endsampl,view)


if view == 1 
    
    figure(Fig)
    H = subplot('position',[left bottom width height]);
    line_handle1 = line([startsampl/fs,startsampl/fs],[min(min(data)),max(max(data))],'Color',[1 0 0],'LineStyle',':','LineWidth',1.5);
    line_handle2 = line([endsampl/fs,endsampl/fs],[min(min(data)),max(max(data))],'Color',[1 0 0],'LineStyle',':','LineWidth',1.5);

end

if view == 6
    
    figure(Fig)
    H = subplot('position',[left bottom width height]);
    line_handle1 = line([startsampl/fs,startsampl/fs],[0,(fs/2)],'Color',[1 0 0],'LineStyle',':','LineWidth',1.5);
    line_handle2 = line([endsampl/fs,endsampl/fs],[0, fs/2],'Color',[1 0 0],'LineStyle',':','LineWidth',1.5);

end