function Output = fxprocessing(data,fs,nbits,a_ID,ParaEingabe)
% function Output = fxprocessing(data,fs,nbits,a_ID,ParaEingabe)
% ******************************************************
% * sourcecode taken from BlockAnalyse.m by Joerg Bitzer
% * Institute for Hearing Technology and Audiology
% * University of Applied Sciences Oldenburg, Germany
% * ----------------------------------------------------
% * Author  :   Dominik Wegmann <audioholiker@web.de>
% * Date    :   10/2005
% * Last modified: Jan-03-2007

a_ID = nonzeros(a_ID); % chosen algorithms
ParaEingabe;  %0: use default values, 1: user input

disp('************** FX-PROCESSING *****************');

t = clock;
% number of algos
NumID = length(a_ID);

% all structs are subsumed in one struct:
% constracted as:
% MetaStr.stAlgo1.xy
% MetaStr.stAlgo2.yz
for(k = 1 : NumID)
    stAlgo = initAlgo(a_ID(k),fs);
    name_str = sprintf('stAlgo%d',k);
    MetaStr.(name_str) = stAlgo;
end


% --- processing of the data---

for(k = 1 : NumID)
    name_str = sprintf('stAlgo%d',k);
    if(~isempty(MetaStr.(name_str)))

        % calling all process function
        ProcessName = MetaStr.(name_str).ProcessName;
        % eval starts the process function
        eval(ProcessName);
    end
end

Output=data;

et = etime(clock,t);
text=['Time elapsed: ',num2str(et),' sec.'];addtext(text);

%--------------------------------------------------------------------------
%--------------------Licence ----------------------------------------------
% Copyright <2005> Dominik Wegmann <audioholiker@web.de>
% Permission is hereby granted, free of charge, to any person obtaining
% a copy of this software and associated documentation files
% (the "Software"), to deal in the Software without restriction, including
% without limitation the rights to use, copy, modify, merge, publish,
% distribute, sublicense, and/or sell copies of the Software, and to
% permit persons to whom the Software is furnished to do so, subject
% to the following conditions:
% The above copyright notice and this permission notice shall be included
% in all copies or substantial portions of the Software.

% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
% EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
% OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
% IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
% CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
% TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
% SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
