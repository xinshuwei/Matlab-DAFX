function text = addtext(text);
global STATUSTEXT
%displays textmessages
text1=get(STATUSTEXT(2),'String');
text2=get(STATUSTEXT(3),'String');
text3=get(STATUSTEXT(4),'String');
text4=get(STATUSTEXT(5),'String');
text5=get(STATUSTEXT(6),'String');
text1=text2;
text2=text3;
text3=text4;
text4=text5;
text5=text;
set(STATUSTEXT(2),'String',text1);
set(STATUSTEXT(3),'String',text2);
set(STATUSTEXT(4),'String',text3);
set(STATUSTEXT(5),'String',text4);
set(STATUSTEXT(6),'String',text5);