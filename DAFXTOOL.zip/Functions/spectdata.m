function H = spectdata(Fig,dat,fs,left,bottom,width,height,undock)

if length(dat) <= fs
    winlen=128;
    olap=64;
end
if length(dat)>fs && length(dat)<=3*fs
    winlen=256;
    olap=128;
end
if length(dat)>3*fs
    winlen=512;
    olap=256;
end
fftlen = 2*winlen;
if undock == 0
    figure(Fig);
    H = subplot('position',[left bottom width height]);
    set(H,'FontSize',8);
    specgram(dat,fftlen,fs,hamming(winlen),olap);xlabel('Time [sec]'), ylabel('Frequency [*10kHz]');
    set(gca,'YDir','normal');%colormap('hsv');

else
    figure()
    specgram(dat,2048,fs,hamming(winlen),olap);xlabel('Time [sec]'), ylabel('Frequency [kHz]');
    set(gca,'YDir','normal');
    colorbar; %colormap('hsv');
end



