function H = envdata(Fig,data,fs,left,bottom,width,height,undock)

he_in = fft(data);                        %fft of input
he_in((2+floor(0.5*end)):end) = 0;        % set negative freqs. to ZERO. 
he_in(1:end-1) = he_in(1:end-1) *2;       % multiply positive samples with 2
env = abs(ifft(he_in));                   %hilbert envelope


[b,a] = butter(4,30/(fs/2));                    %smoothing
env2 = filter(b,a,env);
fak = max(env)/max(env2);env2 = env2.*fak;
%-----------------------------------------------------------------
env_len = length(env2)/fs;
delta_t = 1/fs;
t = 0:delta_t:(env_len-delta_t);
if undock == 0
    figure(Fig);
    H = subplot('position',[left bottom width height]);
    plot(t,env2,'r');axis([0 env_len min(env2)-0.01 max(env2)+0.01]);ylabel('Magnitude');xlabel('Time [s]');set(gca,'YGrid','on');
    set(H,'FontSize',8);
else
    figure()
    plot(t,env2,'r');axis([0 env_len min(env2)-0.01 max(env2)+0.01]);ylabel('Magnitude');xlabel('Time [s]');set(gca,'YGrid','on');
end