function H = ERBSpecdata(Fig,dat,fs,left,bottom,width,height,undock)
%computes the "auditory spectrum" using a n channel gammatone filterbank
%(Patterson et al.);
% The genius ERB codestuff was written by Malcolm Slaney!

nch = 96;%n of ERB Channels
[cf,coeffs] = MakeERBFilters(fs,nch,100,10000);%get filtercoeffs
winlen = 512;
fftlen = 2*winlen;
win = hamming(winlen);
k=1;
pos=1;  

while (pos+winlen <= length(dat))
    frame = dat([pos:pos+winlen-1],1);
    frame = frame.*win;    %windowing
    out = ERBFilterBank(frame,coeffs);%gammatone filtering
    for n=1:nch
    XX(:,n)=(abs(fft(out(n,:),fftlen))).^2;%Powerspec
    Y(k,:,n)=((XX(1:fftlen/2,n)));%first half of XX
    end
    XXX(k,:) =(sum((XX([1:length(XX)/2],:)))+eps);%sum all channels
    pos = pos + winlen/2; %50% overlap
    k=k+1;
end

YY=sum(Y,1);
ZZ=sum(Y,3);
YY=squeeze(YY);
ZZ = squeeze(ZZ);
YY=flipdim(YY,2);
YY=10*log10(YY);
ZZ = 10*log10(ZZ);

f = 0:fs/fftlen:fs/2 - fs/fftlen;
channels = 1:nch;
t = (0:(winlen/2)/fs:((k)*winlen/2)/fs-winlen/fs);

figure(1000); 
subplot(1,2,1)
%mesh(channels,f,YY);view(177,60) %plot freq/ERB 
imagesc(channels,f,YY), axis xy, colormap(jet)
ylim([100 10000]);
xlabel('ERB Channels');ylabel('Frequency ');%zlabel('Power Magnitude(dB)')
title('Frequency Content per ERB Channel (100...10000 Hz)')
subplot(1,2,2)
imagesc(t,f,ZZ'), axis xy, colormap(jet)
xlabel('time');
title('Spec of ERB Output')
ylim([100 10000]);
% set(gca, 'YTick', [1:10000/nch:10000]);
% set(gca, 'YTickLabel', num2str(flipud(cf)));
%axis([0 97 1 fs/2 min(min(YY))-5 max(max(YY))+5]);

% colorbar
if undock == 0
    figure(Fig);
    H = subplot('position',[left bottom width height]);
    set(H,'FontSize',8);

else
    figure()
end
XXX = flipdim(XXX,2);
XXX = 10*log10(sum(XXX)./k);
plot(XXX);
axis([0 nch min(XXX) max(XXX)+1]);grid on;
xlabel('ERB Cannels');ylabel('Power Magnitude [dB] ');
G=legend(['Summed Spectrum,',num2str(nch),' Channel Gammatone Filterbank'],3);set(G,'FontSize',7);
