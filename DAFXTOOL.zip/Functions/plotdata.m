function H = plotdata(F_DAFX,dat,fs,view,left,bottom,width,height,undock)
%plots the data


switch view
    case 1
        timedata(F_DAFX,dat,fs,left,bottom,width,height,undock);
    case 2
        fftdata(F_DAFX,dat,fs,left,bottom,width,height,undock);
    case 3
        fftdata_log(F_DAFX,dat,fs,left,bottom,width,height,undock);
    case 4
        psddata(F_DAFX,dat,fs,left,bottom,width,height,undock);
    case 5
        text=['Computing ERB-Channels...'];addtext(text);
        pause(0.0001);tic
        ERBSpecdata(F_DAFX,dat,fs,left,bottom,width,height,undock);
        text=['elapsed time:',num2str(toc),' s'];addtext(text);
        
    case 6
        spectdata(F_DAFX,dat,fs,left,bottom,width,height,undock);
        
    case 7
        watrfdata(F_DAFX,dat,fs,left,bottom,width,height,undock);

    case 8
        envdata(F_DAFX,dat,fs,left,bottom,width,height,undock);
        
    case 9
        corrdata(F_DAFX,dat,fs,left,bottom,width,height,undock);
        
    case 10
        loudndata(F_DAFX,dat,fs,left,bottom,width,height,undock);
     
    case 11
        pitchdata(F_DAFX,dat,fs,left,bottom,width,height,undock);
        
end