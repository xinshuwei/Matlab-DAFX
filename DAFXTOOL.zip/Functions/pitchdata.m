function H = pitchdata(Fig,dat,fs,left,bottom,width,height,undock)
%pitch detection
ms1=fix(fs/330);                 % maximum speech Fx at 330Hz
ms20=fix(fs/65);                  % minimum speech Fx at 65Hz
%[b,a] = butter(4,0.1); %Tiefpassfilterung
%x = filter(b,a,x);
x=dat;
winlen = 1024;
n = 1;
pos=1;                                           %windowing
while (pos+winlen <= length(x))
    frame = x([pos:pos+winlen-1],1);
    %frame = frame.*hamming(length(winlen));
    Y=fft(frame.*hamming(length(frame)));
    pos = pos + winlen/2; %0% overlap
    %C=fft(log(abs(Y)+eps));
    
    %[c(n),fx(n)]=max(abs(C(ms1:ms20))); %get fx
    %fx(n) = fs/(ms1+fx(n)-1);
    %fprintf('F0_Cepstrum=%gHz\n',fx);
    n = n+1;
    %=========================
    r=xcorr(frame,ms20,'coeff');   %Pitch durch corr.
    r=r(ms20+1:2*ms20+1);
    
    [rmax(n),tx(n)]=max(r(ms1:ms20));%
    tx(n)=fs/(ms1+tx(n)-1);
    %fprintf('F0_Autocorr=%gHz\n',tx);

end

blocks = [1:length(tx)];

if undock == 0
    figure(Fig);
    H = subplot('position',[left bottom width height]);
    set(H,'FontSize',8);

else
    figure()
end


plot(blocks,tx(1:end),'g-*');hold on;
xlabel('Blocks');
ylabel('F0 (Hz)');
legend('F0 via ACF (won�t work on nonspeech signals!)',3);


