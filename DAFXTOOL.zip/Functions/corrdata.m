function corrdata(Fig,dat,fs,left,bottom,width,height,undock)


if size(dat,2)>1
    [c,lags] = xcorr(dat(:,1),dat(:,2),2048);
    correlationcoefficient=corr2(dat(:,1),dat(:,2))
else
    [c,lags] = xcorr(dat,2048);
    correlationcoefficient=corr2(dat,dat)
end
lags=lags/(fs/1000);c=c*(1/max(c));

if undock == 0
    figure(Fig)
    H = subplot('position',[left bottom width height]);

else
    figure()
end
plot(lags,c);
set(gca,'XGrid','on');xlabel('\tau (ms)');ylabel('Corr.(normalized to 1)');

