*********************************************
DAFXTOOL V2.1 
Dominik Wegmann 2006, audioholiker<at>web.de
*********************************************

%SCROLL DOWN FOR ENGLISH VERSION!

dafxtool ist ein Tool zur Darstellung und Bearbeitung von Audiosignalen.
Achtung: Keine Garantie das alles super und richtig programmiert wurde! 
         Jegliche Form von sinnvoller Modifikation ist ausdr�cklich erw�nscht!  

das geht bisher:
- aufnehmen in mono. gew�nschte bits und fs angeben, "record" dr�cken,sound aufnehmen, irgendwann "stop" dr�cken.
  oder aber:
- wav laden (mono und stereo). 
- f�r das signal k�nnen 11 verschiedene Darstellungen gew�hlt werden. links unterm plotfenster darstellung w�hlen. bei stereofile kanal w�hlbar. 
  fft und zeit funktionieren stereo, alle anderen views nur f�r jeweils den gew�hlten kanal.
- da die GUI als normale figure definiert ist, sind alle g�ngigen fig-funktionen verf�gbar(zoom, colorbar, etc.)
- play und stoptaste sind kombiniert, der playbereich kann �ber die slider oben gew�hlt werden
- plugins: alle gelisteten funktionieren im prinzip,nat�rlich recht rudiment�r das ganze... 
- wird kein plugin gew�hlt: output=input. praktisch, um signaltechnische zusammenh�nge darzustellen (oben zeit, unten spectrum z.B.)
- durch slider-bereichswahl kann ein teil des audiofiles herauskopiert werden, wenn kein PlugIn gew�hlt ist.
- unten rechts werden die pegel von input und output angezeigt.

***** �bersicht Funktionen: *****

SigGen:    Signal-Generator
Record:    Nimmt mono auf vom prim�ren Input. Bits und Sampelrate fs lassen sich in den Feldern neben dem Button einstellen.
Load/Save: Laden/Speichern von mono oder stereo-wav-files. Nur Output wird gespeichert!
Play:      Wiedergabe des Audiofiles. 
Region-Sliders: Mit den Slidern oben l�sst sich ein Teil des Files ausw�hlen, nur dieser Bereich wird dann wiedergegeben und von den PlugIns bearbeitet.
                Mit dem Zoom-Tool k�nnen die bereichsmarker recht genau gesetzt werden.
Crop: Bereich wird herausgeschnitten.Um das Ergebnis zu speichern, muss die Bearbeitung durch den "RUN" Button best�tigt werden.
Fade: Bereich wird ein/ausgeblendet. Um das Ergebnis zu speichern, muss die Bearbeitung durch den "RUN" Button best�tigt werden.
PlugIn-Section: Hier sind die verf�gbaren PlugIns gelistet. Einige sind nicht stereo-kompatibel
                Zum erweitern durch eigene Effekte muss die Liste FXNAME/FXID in dafxtool.m erweitert sowie das PlugIn in initAlgo.m eingebunden werden.
default parameter values: F�r die gew�hlten PlugIns werden die voreingestellten Parameter verwendet.
selected region only:     Hiermit wird nur der durch die Slider begrenzte Bereich durch die PlugIns geschickt und dargestellt. 
                          Nutzbar auch zum herauskopieren eines Bereiches in die untere Darstellung. 
                          Auch ohne Anwahl wird nur der gew�hlte Bereich bearbeitet, jedoch dann mit dem �brigen nichtbearbeiteten Signal wieder erg�nzt. 
RUN!: Startet Signalbearbeitung. Ist kein PlugIn gew�hlt: Output = Input. kann sehr praktisch sein um zwei Darstellungen gleichzeituig zu betrachten. 
view: hier kann die gew�nschte darstellung gew�hlt werden (time domain, fft_lin, fft_log, psd, spectrogram,envelope, watrefall, correlation). 
      rechts daneben l�sst sich bei einem stereosignal der kanal w�hlen.     
undock fig: Der plot wird im separaten fenster dargestellt, zum freien skalieren, beschriften und exportieren etc.
Flip Out=>In: Output wird zum Input, so kann man die fade/crop funktion auf Output anwenden und ggf. nochmals durch ein anderes plugin schicken.




***************************************************************************
***************************************************************************
dafxtool is a tool providing multi-visualization and basic fx-processing of audiosignals

****** function overview ********

SigGen:    signal-generator, provides eight signals .
Record:    mono-recording from primary input-device. choose sample frequency fs and bitrate in the fields. recording while replaying is possible.
Load/Save: loading/saving of wav-files. caution! only output can be stored.
Play:      plays audiofile. play while recording is possible.
Region-Sliders: select part of file using the sliders.
Crop: Crop selected region. To save the result you first must define it as output data by clicking "RUN"
Fade: Fade in/out selected region. To save the result you first must define it as output data by clicking "RUN"
PlugIn-Section: audiofx-processing. to add your own effects you need to upgrade the lists FXNAME/FXID in dafxtool.m and set your plugin in initAlgo.m
default parameter values: default parameter values are applied to the chosen plugins.
selected region only: only the slider selected region will be processed and visualized. select no plugin to copy a portion of the file as output.
RUN!: starts signal processing. if no plugin is chosen: output = input. 
view: choose type of signal view (time domain, fft, fft log, psd, spectrogram, envelope, waterfall,auditory spec, correlation,loudness,pitch). 
      if a stereo file is loaded you can select a channel beside the view button
undock fig: plotting in separate figure for larger view, free skaling, editing, exporting...






%**************************************************************************
%******************** Licence *********************************************
% Copyright <2005> Dominik Wegmann <audioholiker@web.de>
% Permission is hereby granted, free of charge, to any person obtaining
% a copy of this software and associated documentation files
% (the "Software"), to deal in the Software without restriction, including
% without limitation the rights to use, copy, modify, merge, publish,
% distribute, sublicense, and/or sell copies of the Software, and to
% permit persons to whom the Software is furnished to do so, subject
% to the following conditions:
% The above copyright notice and this permission notice shall be included
% in all copies or substantial portions of the Software.

% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
% EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
% OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
% IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
% CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
% TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
% SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.